from ursina import *
import platform
from panda3d.core import AntialiasAttrib

class C00lWorld:
    def __init__(self):
        self.app = Ursina()

        # macOS fix
        if platform.system() == "Darwin":
            print(">>> macOS detected: disabling shaders")
            render.setShaderOff()
            render.setAntialias(AntialiasAttrib.MNone)

        # simple world
        Entity(model='plane', color=color.green, scale=10)
        Sky()
        EditorCamera()

    def test_plane(self):
        pass

    def start(self):
        self.app.run()

if __name__ == "__main__":
    game = C00lWorld()
    game.test_plane()
    game.start()

   

 
