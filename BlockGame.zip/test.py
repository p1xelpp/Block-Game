from ezy3d import C00lWorld
from c00lnet import Server, ServerClient
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--mode", choices=["1", "2", "3"], default="1", help="Game mode")
parser.add_argument("--port", type=int, default=27015, help="Port number")
parser.add_argument("--ip", default="localhost", help="Server IP address")
args = parser.parse_args()

mode = args.mode
port = args.port
ip = args.ip
net = None
server = None

if mode == "2":
    server = Server(port=port)
    net = ServerClient()
    if not net.connect("localhost", port):
        raise SystemExit("Could not connect to local server")
elif mode == "3":
    net = ServerClient()
    if not net.connect(ip, port):
        raise SystemExit(f"Could not connect to server {ip}:{port}")
elif mode != "1":
    raise SystemExit("Invalid mode. Use 1, 2, or 3.")

if mode == "1":
    game = C00lWorld()
else:
    if net is None or not net.connected:
        raise SystemExit("Server not found or connection failed.")
    game = C00lWorld(network=net)

if mode == "1":
    game = C00lWorld()
else:
    if net is None or not net.connected:
        raise SystemExit("Server not found or connection failed.")
    game = C00lWorld(network=net)

game.test_plane()
game.start()