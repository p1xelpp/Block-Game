@echo off
echo ============================================
echo Block Game - Build Setup.exe
echo ============================================
echo.
echo Step 1: Installing build tools...
pip install pyinstaller -q
echo ✓ Build tools ready
echo.
echo Step 2: Building executable for Windows (this takes a few minutes)...
python build_exe.py --target=windows
echo.
echo Done! Your game is ready in: dist\windows\BlockGame.exe
pause
