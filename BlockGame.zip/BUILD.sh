#!/usr/bin/env bash
set -e

echo "============================================"
echo "Block Game - Build Setup"
echo "============================================"
echo
echo "Step 1: Installing build tools..."
pip install pyinstaller -q
if [ $? -ne 0 ]; then
  echo "Failed to install PyInstaller."
  exit 1
fi

target=${1:-}
if [ -z "$target" ]; then
  target=$(uname | tr '[:upper:]' '[:lower:]')
  if [[ "$target" == darwin* ]]; then
    target="mac"
  elif [[ "$target" == linux* ]]; then
    target="linux"
  fi
fi

if [[ "$target" != "windows" && "$target" != "mac" && "$target" != "linux" ]]; then
  echo "Usage: ./BUILD.sh [mac|linux]"
  exit 1
fi

echo "✓ Build tools ready"
echo
echo "Step 2: Building executable for $target (this takes a few minutes)..."
python3 build_exe.py --target="$target"
echo
if [[ "$target" == "windows" ]]; then
  echo "Done! Your game is ready in: dist/windows/BlockGame.exe"
elif [[ "$target" == "mac" ]]; then
  echo "Done! Your game is ready in: dist/mac/"
else
  echo "Done! Your game is ready in: dist/linux/"
fi
