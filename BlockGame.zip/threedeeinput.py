# ================================================================
# 3D INPUT MODULE — DOOM + MOUSE + LMB/RMB CAMERA + BLOCK CONTROL
# ================================================================
from ursina import *


class DoomInput3D:
    def __init__(self, world, player, sensitivity=50, arrow_speed=80):
        self.world = world          # toegang tot blocks, textures, etc.
        self.player = player
        self.sensitivity = sensitivity
        self.arrow_speed = arrow_speed

        # DOOM-style: geen pointer lock
        mouse.locked = False

    # ============================================================
    # UPDATE: camera draaien met muis + arrow keys
    # ============================================================
    def update(self):
        if not self.player:
            return

        # --- 1. Mouse look ---
        mx = mouse.velocity[0] * self.sensitivity
        my = mouse.velocity[1] * self.sensitivity

        self.player.rotation_y += mx
        camera.rotation_x -= my
        camera.rotation_x = clamp(camera.rotation_x, -80, 80)

        # --- 2. Arrow keys look ---
        if held_keys['left arrow']:
            self.player.rotation_y += self.arrow_speed * time.dt
        if held_keys['right arrow']:
            self.player.rotation_y -= self.arrow_speed * time.dt
        if held_keys['up arrow']:
            camera.rotation_x -= self.arrow_speed * time.dt
            camera.rotation_x = clamp(camera.rotation_x, -80, 80)
        if held_keys['down arrow']:
            camera.rotation_x += self.arrow_speed * time.dt
            camera.rotation_x = clamp(camera.rotation_x, -80, 80)

    # ============================================================
    # INPUT: LMB/RMB block placement & destroy
    # ============================================================
    def input(self, key):
        if key == 'left mouse down':
            self.place_block()

        if key == 'right mouse down':
            self.destroy_block()

    # ============================================================
    # BLOCK FUNCTIONS
    # ============================================================
    def place_block(self):
        hit = raycast(
            self.player.position + Vec3(0, 0.5, 0),
            self.player.forward,
            distance=5,
            ignore=[self.player]
        )
        if hit.hit:
            pos = hit.position + hit.normal
            pos = Vec3(round(pos.x), round(pos.y), round(pos.z))
            self.world.blocks[pos] = self.world.BlockClass(
                position=pos,
                texture=self.world.block_texture
            )

    def destroy_block(self):
        hit = raycast(
            self.player.position + Vec3(0, 0.5, 0),
            self.player.forward,
            distance=5,
            ignore=[self.player]
        )
        if hit.hit and isinstance(hit.entity, self.world.BlockClass):
            destroy(hit.entity)
            self.world.blocks.pop(hit.entity.position, None)
