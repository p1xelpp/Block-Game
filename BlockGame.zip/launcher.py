# ================================================================
#  MACOS RENDERING PATCH — MUST RUN BEFORE ANY URSINA IMPORTS
# ================================================================
import platform
if platform.system() == "Darwin":
    from panda3d.core import loadPrcFileData
    # Probeer eerst gewoon correcte GL settings te forceren
    loadPrcFileData('', 'gl-version 3 2')
    loadPrcFileData('', 'gl-force-version 3 2')
    loadPrcFileData('', 'gl-profile core')
    loadPrcFileData('', 'basic-shaders-only #t')
    loadPrcFileData('', 'framebuffer-srgb false')
    loadPrcFileData('', 'aux-display pandagl')
# ================================================================

import argparse
import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import sys
import os


class BlockGameLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("Block Game Launcher")
        self.root.geometry("500x400")
        self.root.resizable(True, True)

        # Center window on screen
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')

        style = ttk.Style()
        style.theme_use('clam')

        title = ttk.Label(self.root, text="Block Game", font=("Arial", 24, "bold"))
        title.pack(pady=20)

        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        mode_label = ttk.Label(main_frame, text="Select Game Mode:", font=("Arial", 12, "bold"))
        mode_label.pack(pady=10)

        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)

        self.sp_btn = ttk.Button(button_frame, text="Singleplayer", command=self.launch_singleplayer)
        self.sp_btn.pack(fill=tk.X, pady=5)

        self.host_btn = ttk.Button(button_frame, text="Host Multiplayer", command=self.show_host_options)
        self.host_btn.pack(fill=tk.X, pady=5)

        self.join_btn = ttk.Button(button_frame, text="Join Multiplayer", command=self.show_join_options)
        self.join_btn.pack(fill=tk.X, pady=5)

        self.options_frame = ttk.LabelFrame(main_frame, text="Options", padding=10)
        self.options_frame.pack(fill=tk.X, pady=10)

        # Host options
        self.host_frame = ttk.Frame(self.options_frame)
        ttk.Label(self.host_frame, text="Port:").pack(side=tk.LEFT, padx=5)
        self.port_var = tk.StringVar(value="27015")
        self.port_entry = ttk.Entry(self.host_frame, textvariable=self.port_var, width=10)
        self.port_entry.pack(side=tk.LEFT, padx=5)
        self.host_load_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self.host_frame, text="Import saved world on host start", variable=self.host_load_var).pack(side=tk.LEFT, padx=5)
        ttk.Button(self.host_frame, text="Start Host", command=self.launch_host).pack(side=tk.LEFT, padx=5)
        ttk.Button(self.host_frame, text="Cancel", command=self.hide_options).pack(side=tk.LEFT, padx=2)

        # Join options
        self.join_frame = ttk.Frame(self.options_frame)
        ttk.Label(self.join_frame, text="Server Address:").pack(side=tk.LEFT, padx=5)
        self.server_address_var = tk.StringVar(value="localhost:27015")
        self.server_address_entry = ttk.Entry(self.join_frame, textvariable=self.server_address_var, width=20)
        self.server_address_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(self.join_frame, text="Connect", command=self.launch_join).pack(side=tk.LEFT, padx=5)
        ttk.Button(self.join_frame, text="Cancel", command=self.hide_options).pack(side=tk.LEFT, padx=2)

    def show_host_options(self):
        self.host_frame.pack(fill=tk.X, padx=5, pady=5)
        self.join_frame.pack_forget()

    def show_join_options(self):
        self.join_frame.pack(fill=tk.X, padx=5, pady=5)
        self.host_frame.pack_forget()

    def hide_options(self):
        self.host_frame.pack_forget()
        self.join_frame.pack_forget()

    def launch_singleplayer(self):
        self.launch_game("1")

    def launch_host(self):
        port = self.port_var.get()
        if not port.isdigit() or not (1 <= int(port) <= 65535):
            messagebox.showerror("Invalid Port", "Port must be between 1 and 65535")
            return
        self.launch_game("2", port, load_save=self.host_load_var.get())

    def launch_join(self):
        server_address = self.server_address_var.get()

        if ':' not in server_address:
            messagebox.showerror("Invalid Format", "Use format: server:port")
            return

        try:
            server, port_str = server_address.rsplit(':', 1)
            port = int(port_str)

            if not (1 <= port <= 65535):
                messagebox.showerror("Invalid Port", "Port must be between 1 and 65535")
                return

            if not server:
                messagebox.showerror("Invalid Server", "Server cannot be empty")
                return

            self.launch_game("3", port, server)
        except ValueError:
            messagebox.showerror("Invalid Port", "Port must be a number")

    def launch_game(self, mode, port=None, ip=None, load_save=False):
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            launcher_script = os.path.join(script_dir, os.path.basename(__file__))

            if getattr(sys, 'frozen', False):
                cmd = [sys.executable, '--run-game', '--mode', mode]
            else:
                cmd = [sys.executable, launcher_script, '--run-game', '--mode', mode]

            if mode == "2":
                cmd.extend(['--port', str(port), '--save-on-exit'])
                if load_save:
                    cmd.append('--load-save')
            elif mode == "3":
                cmd.extend(['--ip', ip, '--port', str(port)])

            subprocess.Popen(
                cmd,
                cwd=script_dir,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == 'win32' else 0
            )

            messagebox.showinfo("Launching", "Game is starting...")
            self.hide_options()

        except Exception as e:
            messagebox.showerror("Launch Error", f"Failed to launch game:\n{str(e)}")


def run_game(mode, port, ip, load_save=False, save_on_exit=False, save_path=None):
    from ezy3d import C00lWorld
    from c00lnet import Server, ServerClient

    net = None
    server = None

    if mode == "2":
        server = Server(port=port)
        net = ServerClient()
        if not net.connect("localhost", port):
            raise SystemExit("Could not connect to local server")
    elif mode == "3":
        net = ServerClient()
        if not net.connect(ip, port):
            raise SystemExit(f"Could not connect to server {ip}:{port}")
    elif mode != "1":
        raise SystemExit("Invalid mode. Use 1, 2, or 3.")

    if mode == "1":
        game = C00lWorld(load_on_start=load_save, save_on_exit=save_on_exit, save_path=save_path)
    else:
        if net is None or not net.connected:
            raise SystemExit("Server not found or connection failed.")
        game = C00lWorld(network=net, load_on_start=load_save, save_on_exit=save_on_exit, save_path=save_path)

    game.test_plane()
    game.start()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-game', action='store_true')
    parser.add_argument('--mode', choices=['1', '2', '3'], default='1')
    parser.add_argument('--port', type=int, default=27015)
    parser.add_argument('--ip', default='localhost')
    parser.add_argument('--load-save', action='store_true')
    parser.add_argument('--save-on-exit', action='store_true')
    parser.add_argument('--save-path', default=None)
    args, unknown = parser.parse_known_args()

    if args.run_game:
        run_game(args.mode, args.port, args.ip, load_save=args.load_save,
                 save_on_exit=args.save_on_exit, save_path=args.save_path)
    else:
        root = tk.Tk()
        launcher = BlockGameLauncher(root)
        root.mainloop()


if __name__ == "__main__":
    main()
