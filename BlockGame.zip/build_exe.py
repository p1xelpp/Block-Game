#!/usr/bin/env python3
"""
Build script to create a standalone .exe for the Block Game
Run: python build_exe.py
"""

import argparse
import PyInstaller.__main__
import os
import sys

# Get the directory where this script is located
base_dir = os.path.dirname(os.path.abspath(__file__))

parser = argparse.ArgumentParser(description="Build Block Game for the current platform")
parser.add_argument("--target", choices=["windows", "linux", "mac"], help="Platform to build for")
parser.add_argument("--icon", help="Path to a custom icon file")
parser.add_argument("--onedir", action="store_true", help="Build into a directory instead of a single file")
args = parser.parse_args()

if args.target:
    target = args.target
elif sys.platform.startswith("win"):
    target = "windows"
elif sys.platform == "darwin":
    target = "mac"
elif sys.platform.startswith("linux"):
    target = "linux"
else:
    raise SystemExit(f"Unsupported platform: {sys.platform}")

# Determine the icon file
icon_path = None
if args.icon:
    icon_path = args.icon if os.path.isabs(args.icon) else os.path.join(base_dir, args.icon)
    if not os.path.isfile(icon_path):
        raise SystemExit(f"Icon file not found: {icon_path}")
else:
    if target == "windows":
        icon_candidates = [
            os.path.join(base_dir, "favicon.ico"),
            os.path.join(base_dir, "fancy stuff", "favicon.ico"),
        ]
    elif target == "mac":
        icon_candidates = [
            os.path.join(base_dir, "favicon.icns"),
            os.path.join(base_dir, "fancy stuff", "favicon.icns"),
        ]
    else:
        icon_candidates = [
            os.path.join(base_dir, "favicon.ico"),
            os.path.join(base_dir, "fancy stuff", "favicon.ico"),
        ]
    for ico in icon_candidates:
        if os.path.isfile(ico):
            icon_path = ico
            break

icon_arg = f"--icon={icon_path}" if icon_path else "--icon=NONE"
build_mode = "--onedir" if args.onedir else "--onefile"

# Build output folders by target
args_list = [
    'launcher.py',  # Entry point - GUI launcher
    build_mode,
    '--windowed',  # GUI app, no console needed
    '--name=BlockGame',  # Name of the executable
    f'--distpath={os.path.join(base_dir, "dist", target)}',
    f'--workpath={os.path.join(base_dir, "build", target)}',
    '--specpath=.',  # Spec file location
    icon_arg,
    '--add-data=.:.',  # Include any data files in current directory
    # Panda3D/Ursina dependencies
    '--hidden-import=panda3d',
    '--hidden-import=panda3d.core',
    '--hidden-import=ursina',
    '--hidden-import=ursina.prefabs.first_person_controller',
    '--collect-all=panda3d',
    '--collect-all=ursina',
]

print(f"Building Block Game executable for {target}...")
print("This may take a few minutes on first run...")
print("(Including Panda3D graphics libraries...)")
print(f"Output folder: dist/{target}")
if icon_path:
    print(f"Using icon: {icon_path}")

try:
    PyInstaller.__main__.run(args_list)
    print("\n✓ Success! Your executable is in the dist folder")
    print(f"  Location: {os.path.join('dist', target)}")
except Exception as e:
    print(f"\n✗ Build failed: {e}")
    sys.exit(1)
