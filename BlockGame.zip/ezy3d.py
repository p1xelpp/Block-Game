import __main__
import json
import os
import uuid
from pathlib import Path
from queue import Queue
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

class CrouchFirstPersonController(FirstPersonController):
    def __init__(self, crouch_height=1, crouch_speed_factor=0.4, **kwargs):
        self.crouch_height = crouch_height
        self.crouch_speed_factor = crouch_speed_factor
        super().__init__(**kwargs)
        self.stand_height = self.height
        self.walk_speed = self.speed
        self.crouching = False
        self.last_position = Vec3(self.position)

    def update(self):
        if held_keys['shift']:
            if not self.crouching:
                self.crouching = True
                self.height = self.crouch_height
                if hasattr(self, 'camera_pivot'):
                    self.camera_pivot.y = self.height
                self.speed = self.walk_speed * self.crouch_speed_factor
        else:
            if self.crouching:
                self.crouching = False
                self.height = self.stand_height
                if hasattr(self, 'camera_pivot'):
                    self.camera_pivot.y = self.height
                self.speed = self.walk_speed

        super().update()

        if self.crouching:
            direction = Vec3(
                self.forward * (held_keys['w'] - held_keys['s'])
                + self.right * (held_keys['d'] - held_keys['a'])
            )
            if direction.length() > 0.001:
                direction.y = 0
                direction = direction.normalized()
                start = self.world_position + direction * 0.5 + Vec3(0, self.height, 0)
                ray = raycast(start, Vec3(0, -1, 0), traverse_target=self.traverse_target,
                              ignore=self.ignore_list, distance=self.height + 0.2)
                if not ray.hit:
                    self.position = self.last_position

        self.last_position = Vec3(self.position)

class C00lWorld:
    def __init__(self, world_width=50, world_depth=50, block_size=1,
                 player_speed=7, mouse_sensitivity=Vec2(30, 30),
                 jump_height=1, jump_up_duration=0.2, fall_after=0.2, gravity=1,
                 network=None, save_path=None, load_on_start=False, save_on_exit=False):
        self.app = Ursina()
        self.player = None
        self.player_model = None
        self.debug_text = None
        self.help_text = None
        self.status_text = None
        self.third_person = False
        self.third_person_distance = 4
        self.third_person_height = 1.4
        self.world_width = world_width
        self.world_depth = world_depth
        self.block_size = block_size
        self.player_speed = player_speed
        self.mouse_sensitivity = mouse_sensitivity
        self.jump_height = jump_height
        self.jump_up_duration = jump_up_duration
        self.fall_after = fall_after
        self.gravity = gravity
        self.network = network
        self.network_queue = Queue()
        self.remote_players = {}
        self.blocks = {}
        self.client_id = uuid.uuid4().hex
        self.last_sent_pos = None
        self.last_sent_rot = 0
        self.block_textures = ['white_cube', 'brick', 'shore', 'grass', 'noise']
        self.block_texture_index = 0
        self.block_texture = self.block_textures[self.block_texture_index]
        self.block_color = color.gray
        self.max_debug_messages = 20
        self.save_path = Path(save_path) if save_path else Path.home() / '.BlockGame' / 'BlockGameSave.json'
        self.save_path.parent.mkdir(parents=True, exist_ok=True)
        self.load_on_start = load_on_start
        self.save_on_exit = save_on_exit
        
        # Create a helper entity that will run updates automatically
        self.update_helper = Entity(parent=scene, visible=False)
        self.update_helper.update = self._custom_update
        # Set input handler in __main__ so Ursina can find it
        __main__.input = self.input

    def test_plane(self):
        Entity(model='plane', scale=(self.world_width, 1, self.world_depth),
               texture='white_cube', color=color.green,
               texture_scale=(self.world_width, self.world_depth), collider='box')
        self.player = CrouchFirstPersonController(height=1,
                                                    crouch_height=0.6,
                                                    crouch_speed_factor=0.4,
                                                    y=1.2,
                                                    origin_y=-.5,
                                                    speed=self.player_speed,
                                                    mouse_sensitivity=self.mouse_sensitivity,
                                                    jump_height=self.jump_height,
                                                    jump_up_duration=self.jump_up_duration,
                                                    fall_after=self.fall_after,
                                                    gravity=self.gravity)
        self.player_model = Entity(parent=self.player,
                                   model='cube',
                                   color=color.azure,
                                   scale=Vec3(1, 1, 1),
                                   position=Vec3(0, 0.5, 0),
                                   collider=None,
                                   enabled=False)
        Sky(color=color.cyan)
        
        self.debug_text = Text(text='', origin=(-.5,.5), y=.45, x=-0.6, scale=1.5, background=True)
        self.debug_text.enabled = False
        self.help_text = Text(text='ESC: quit | F7: toggle view | F2: toggle cursor | F1: help | F3: debug log | F4: cycle texture | Shift: crouch | F11: fullscreen | LMB: place | RMB: destroy',
                              origin=(-.5,.5), y=.45, x=-0.45, scale=1.2, background=True)
        self.help_text.enabled = False
        self.status_text = Text(text='', origin=(-.5,.5), y=.35, x=-0.45, scale=1.2, color=color.yellow, background=True)
        self.status_text.enabled = False
        self.save_info_text = Text(text='F5: save | F6: load', origin=(-.5,.5), y=.3, x=-0.45, scale=1.0, background=True)
        self.save_info_text.enabled = False

        self.save_button = Button(text='Save', scale=(0.1, 0.06), x=-0.7, y=-0.45, color=color.azure, on_click=lambda: self.save_world())
        self.load_button = Button(text='Load', scale=(0.1, 0.06), x=-0.55, y=-0.45, color=color.orange, on_click=lambda: self.load_world())
        self.save_button.enabled = False
        self.load_button.enabled = False

        if self.network:
            self.attach_network(self.network)

        # Load a saved world only when requested by launcher or CLI
        if self.load_on_start and self.save_path.exists():
            self.load_world()

    def attach_network(self, network):
        self.network = network
        self.network.on_message = self._on_network_message
        self._show_status('Connected to multiplayer', duration=3)
        if self.player:
            position = self.player.position
        else:
            position = Vec3(0, 0, 0)
        self.network.send({
            'type': 'hello',
            'id': self.client_id,
            'x': position.x,
            'y': position.y,
            'z': position.z,
            'rotation_y': self.player.rotation_y if self.player else 0,
        })
        self.network.send({
            'type': 'sync-request',
            'id': self.client_id,
        })

    def _position_to_key(self, position):
        pos = Vec3(position)
        return (round(pos.x, 3), round(pos.y, 3), round(pos.z, 3))

    def _texture_to_name(self, texture):
        if isinstance(texture, str):
            return texture
        if hasattr(texture, 'name') and isinstance(texture.name, str):
            return texture.name
        if hasattr(texture, 'texture') and isinstance(texture.texture, str):
            return texture.texture
        return str(texture)

    def _serialize_value(self, value):
        if isinstance(value, Vec3):
            return [value.x, value.y, value.z]
        if isinstance(value, tuple):
            return list(value)
        if isinstance(value, list):
            return [self._serialize_value(item) for item in value]
        if isinstance(value, (int, float, str, bool)) or value is None:
            return value
        if hasattr(value, 'name') and isinstance(value.name, str):
            return value.name
        if hasattr(value, 'texture') and isinstance(value.texture, str):
            return value.texture
        if hasattr(value, '__iter__'):
            try:
                return [self._serialize_value(item) for item in value]
            except Exception:
                pass
        return str(value)

    def _snap_to_grid(self, position):
        pos = Vec3(position)
        half = self.block_size / 2
        return Vec3(
            round((pos.x - half) / self.block_size) * self.block_size + half,
            round((pos.y - half) / self.block_size) * self.block_size + half,
            round((pos.z - half) / self.block_size) * self.block_size + half,
        )

    def _place_block(self, position, scale=1, send_network=False, texture=None, color_value=None):
        pos = self._snap_to_grid(position)
        key = self._position_to_key(pos)
        if key in self.blocks:
            return
        texture = texture or self.block_texture
        color_value = color_value or self.block_color
        self.blocks[key] = Block(position=pos, scale=scale, texture=texture, color=color_value)
        if send_network and self.network:
            msg = {
                'type': 'place',
                'id': self.client_id,
                'x': pos.x,
                'y': pos.y,
                'z': pos.z,
                'scale': scale,
                'texture': self._texture_to_name(texture),
            }
            print(f"[NETWORK SEND] place {msg}")
            self._debug_log(f"[NETWORK SEND] place {msg}")
            self.network.send(msg)

    def _destroy_block_entity(self, block, send_network=False):
        if not block:
            return
        position = Vec3(block.position)
        key = self._position_to_key(position)
        self.blocks.pop(key, None)
        destroy(block)
        if send_network and self.network:
            msg = {
                'type': 'destroy',
                'id': self.client_id,
                'x': position.x,
                'y': position.y,
                'z': position.z,
            }
            print(f"[NETWORK SEND] destroy {msg}")
            self._debug_log(f"[NETWORK SEND] destroy {msg}")
            self.network.send(msg)

    def _destroy_block_at(self, position):
        position = self._snap_to_grid(position)
        key = self._position_to_key(position)
        block = self.blocks.pop(key, None)
        if block:
            destroy(block)

    def _on_network_message(self, msg):
        print(f"[NETWORK RECV] {msg}")
        self._debug_log(f"[NETWORK RECV] {msg}")
        self.network_queue.put(msg)

    def _handle_network_message(self, msg):
        if not isinstance(msg, dict):
            return
        msg_id = msg.get('id')
        if msg_id == self.client_id:
            return
        mtype = msg.get('type')
        if mtype == 'hello':
            if msg_id not in self.remote_players:
                self.remote_players[msg_id] = Entity(model='cube', color=color.orange,
                                                     scale=1, collider=None)
                self._show_status('Remote player joined')
            player = self.remote_players[msg_id]
            player.position = Vec3(msg.get('x', 0), msg.get('y', 0), msg.get('z', 0))
            player.rotation_y = msg.get('rotation_y', player.rotation_y)
            if self.blocks:
                self.network.send({
                    'type': 'sync',
                    'id': self.client_id,
                    'blocks': [
                        {
                            'x': key[0],
                            'y': key[1],
                            'z': key[2],
                            'scale': block.scale,
                            'texture': getattr(block, 'texture', self.block_texture),
                        }
                        for key, block in self.blocks.items()
                    ]
                })
        elif mtype == 'sync-request':
            if self.blocks:
                self.network.send({
                    'type': 'sync',
                    'id': self.client_id,
                    'blocks': [
                        {
                            'x': key[0],
                            'y': key[1],
                            'z': key[2],
                            'scale': block.scale,
                            'texture': getattr(block, 'texture', self.block_texture),
                        }
                        for key, block in self.blocks.items()
                    ]
                })
        elif mtype == 'pos':
            if msg_id not in self.remote_players:
                self.remote_players[msg_id] = Entity(model='cube', color=color.orange,
                                                     scale=1, collider=None)
            player = self.remote_players[msg_id]
            player.position = Vec3(msg.get('x', 0), msg.get('y', 0), msg.get('z', 0))
            player.rotation_y = msg.get('rotation_y', player.rotation_y)
        elif mtype == 'place':
            position = Vec3(msg.get('x', 0), msg.get('y', 0), msg.get('z', 0))
            self._place_block(position,
                              scale=msg.get('scale', 1),
                              send_network=False,
                              texture=msg.get('texture'),
                              color_value=self.block_color)
            print(f"[NETWORK APPLY] place from {msg_id} at {position}")
            self._show_status('Remote placed a block')
        elif mtype == 'destroy':
            position = Vec3(msg.get('x', 0), msg.get('y', 0), msg.get('z', 0))
            self._destroy_block_at(position)
            print(f"[NETWORK APPLY] destroy from {msg_id} at {position}")
            self._show_status('Remote removed a block')
        elif mtype == 'sync':
            for block in msg.get('blocks', []):
                self._place_block(Vec3(block.get('x', 0), block.get('y', 0), block.get('z', 0)),
                                  scale=block.get('scale', 1),
                                  send_network=False,
                                  texture=block.get('texture', self.block_texture),
                                  color_value=self.block_color)
            self._show_status('Remote world synced')

    def _show_status(self, message, duration=3):
        if not self.status_text:
            return
        self.status_text.text = message
        self.status_text.enabled = True
        invoke(self._hide_status, delay=duration)

    def _hide_status(self):
        if self.status_text:
            self.status_text.enabled = False

    def _debug_log(self, message):
        self.debug_messages.append(str(message))
        if len(self.debug_messages) > self.max_debug_messages:
            self.debug_messages.pop(0)

    def input(self, key):
        if key == 'f3':
            print("key F3 pressed")
            self.debug_text.enabled = not self.debug_text.enabled
            
        if key == 'f7':
            print("key F7 pressed")
            self.third_person = not self.third_person
            self.player_model.enabled = self.third_person
            if self.third_person:
                camera.parent = scene
                camera.position = self.player.world_position - self.player.forward * self.third_person_distance + Vec3(0, self.third_person_height, 0)
                camera.look_at(self.player.world_position + Vec3(0, self.third_person_height, 0))
            else:
                camera.parent = self.player.camera_pivot
                camera.position = Vec3.zero
                camera.rotation = Vec3.zero

        if key == 'f1':
            print("key F1 pressed")
            show_help = not self.help_text.enabled
            self.help_text.enabled = show_help
            self.save_info_text.enabled = show_help
            self.save_button.enabled = show_help
            self.load_button.enabled = show_help

        if key == 'f2':
            print("key F2 pressed")
            mouse.locked = not mouse.locked
            print(f"mouse locked = {mouse.locked}")

        if key == 'f11':
            print("key F11 pressed")
            window.fullscreen = not window.fullscreen

        if key == 'f4':
            self.block_texture_index = (self.block_texture_index + 1) % len(self.block_textures)
            self.block_texture = self.block_textures[self.block_texture_index]
            self._show_status(f'Block texture: {self.block_texture}')
            print(f"Block texture set to {self.block_texture}")

        if key == 'escape':
            print("Escape pressed, quitting")
            if self.save_on_exit:
                self.save_world()
            application.quit()
            return

        if key == 'f9':
            print("key F9 pressed")
            self.save_world()

        if key == 'f8':
            print("key F8 pressed")
            if self.load_world():
                self._show_status('World loaded', duration=3)

        # BETER: blocks plaatsen in input() ipv update() 
        # Dan spamt ie niet 60x per seconde
        if key == 'left mouse down':
            hit_info = raycast(camera.world_position, camera.forward, distance=10)
            if hit_info.hit:
                if isinstance(hit_info.entity, Block) and hit_info.normal.y > 0.7:
                    position = hit_info.entity.position + Vec3(0, self.block_size, 0)
                else:
                    position = hit_info.world_point + hit_info.normal * (self.block_size / 2)
                self._place_block(position, scale=self.block_size, send_network=bool(self.network))
                print("key left mouse down pressed")

        if key == 'right mouse down':
            hit_info = raycast(camera.world_position, camera.forward, distance=10)
            if hit_info.hit and isinstance(hit_info.entity, Block):
                self._destroy_block_entity(hit_info.entity, send_network=bool(self.network))
                print("key right mouse down pressed")
    def _custom_update(self):
        """Handle network messages and player state - called every frame by entity update"""
        while not self.network_queue.empty():
            msg = self.network_queue.get()
            self._handle_network_message(msg)

        if self.network and self.player:
            if self.last_sent_pos is None or (self.player.position - self.last_sent_pos).length() > 0.01 or abs(self.player.rotation_y - self.last_sent_rot) > 1:
                self.network.send({
                    'type': 'pos',
                    'id': self.client_id,
                    'x': self.player.position.x,
                    'y': self.player.position.y,
                    'z': self.player.position.z,
                    'rotation_y': self.player.rotation_y,
                })
                self.last_sent_pos = Vec3(self.player.position)
                self.last_sent_rot = self.player.rotation_y

        if self.third_person and self.player:
            camera.parent = scene
            target_position = self.player.world_position - self.player.forward * self.third_person_distance + Vec3(0, self.third_person_height, 0)
            camera.position = lerp(camera.position, target_position, min(1, 6 * time.dt))
            camera.look_at(self.player.world_position + Vec3(0, self.third_person_height, 0))
        elif self.player:
            camera.parent = self.player.camera_pivot
            camera.position = Vec3.zero
            camera.rotation = Vec3.zero

        if self.debug_text and self.debug_text.enabled and self.player:
            debug_text_lines = [f'XYZ: {self.player.x:.1f} {self.player.y:.1f} {self.player.z:.1f}',
                                 f'FPS: {int(window.fps_counter.fps)}']
            debug_text_lines.extend(self.debug_messages[-self.max_debug_messages:])
            self.debug_text.text = '\n'.join(debug_text_lines)
        
    def _clear_saved_blocks(self):
        for block in list(self.blocks.values()):
            destroy(block)
        self.blocks.clear()

    def save_world(self):
        blocks = []
        for key, block in self.blocks.items():
            blocks.append({
                'x': self._serialize_value(key[0]),
                'y': self._serialize_value(key[1]),
                'z': self._serialize_value(key[2]),
                'scale': self._serialize_value(block.scale),
                'texture': self._serialize_value(getattr(block, 'texture', self.block_texture)),
                'color': [self._serialize_value(block.color.r),
                          self._serialize_value(block.color.g),
                          self._serialize_value(block.color.b),
                          self._serialize_value(block.color.a)],
            })

        data = {
            'blocks': blocks,
            'player': {
                'x': self.player.x if self.player else 0,
                'y': self.player.y if self.player else 1.2,
                'z': self.player.z if self.player else 0,
                'rotation_y': self.player.rotation_y if self.player else 0,
            }
        }

        try:
            self.save_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.save_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            self._show_status('World saved', duration=3)
            print(f"World saved to {self.save_path}")
        except Exception as e:
            self._show_status(f'Save failed: {e}', duration=3)
            print(f"Failed to save world: {e}")

    def load_world(self):
        if not self.save_path.exists():
            self._show_status('Save file not found', duration=3)
            return False

        try:
            with open(self.save_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            self._clear_saved_blocks()
            for block_data in data.get('blocks', []):
                position = Vec3(block_data.get('x', 0), block_data.get('y', 0), block_data.get('z', 0))
                raw_scale = block_data.get('scale', 1)
                if isinstance(raw_scale, list) and len(raw_scale) == 3:
                    scale_value = Vec3(raw_scale[0], raw_scale[1], raw_scale[2])
                else:
                    scale_value = raw_scale
                block_color = block_data.get('color', [0.5, 0.5, 0.5, 1])
                self._place_block(
                    position,
                    scale=scale_value,
                    send_network=False,
                    texture=block_data.get('texture', self.block_texture),
                    color_value=Color(block_color[0], block_color[1], block_color[2], block_color[3])
                )

            player_data = data.get('player', {})
            if self.player:
                self.player.position = Vec3(player_data.get('x', 0), player_data.get('y', 1.2), player_data.get('z', 0))
                self.player.rotation_y = player_data.get('rotation_y', 0)

            print(f"World loaded from {self.save_path}")
            return True
        except Exception as e:
            self._show_status('Load failed', duration=3)
            print(f"Failed to load world: {e}")
            return False

    def start(self):
        self.app.run()

class Block(Entity):
    def __init__(self, position=(0,0,0), scale=1, texture='white_cube', color=color.gray):
        super().__init__(
            model='cube',
            texture=texture,
            color=color,
            position=position,
            scale=scale,
            collider='box'
        )